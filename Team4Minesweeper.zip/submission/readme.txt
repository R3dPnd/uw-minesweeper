all team member names
    - Preston Harms
    - Richard Le
an estimate of how much time it took you to complete all deliverables
    - 4 hours
any shortcomings your solution has
    - The solution is fairly simple and does not account for any edge cases.